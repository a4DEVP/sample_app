import React, { useState, useEffect } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { SketchPicker } from 'react-color';
import Slider from 'react-rangeslider';
import Header from "./Header";
import "./FormPage.css"
// To include the default styles
import 'react-rangeslider/lib/index.css';

export default function FormPage() {
  const Title ="Fill the form";	
  const [errState, setErrState] = useState([]);
  const [state, setState] = useState({
    name: "",
    email: "",
	dob: "",
	color: "",
	salary: 0,
  });

  const [showColor, setshowColor] = useState(false);

  const handleInputChange = (event) => {
    setState((prevProps) => ({
      ...prevProps,
      [event.target.name]: event.target.value
    }));
  };

  const setDate = (date) => {
	setState((prevProps) => ({
		...prevProps,
		['dob']: date
	  }));
  }
 
  const handleChangeComplete = (color) => {
	setState((prevProps) => ({
		...prevProps,
		['color']: color.hex
	  }));
  };

  const showPicker = ()=>{
	setshowColor(!showColor);
  }
  const cover = {
	position: 'fixed',
	top: '0px',
	right: '0px',
	bottom: '0px',
	left: '0px',
  }

  const handleChange = value => {
	setState((prevProps) => ({
		...prevProps,
		['salary']: value
	  }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
	let errArray =[];
	Object.keys(state).forEach(function (key) {
		if(key == "email"){
			const emailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
			if(!state[key].match(emailformat)){
				errArray.push(key)
			}
		}
		if(!state[key]){
			errArray.push(key)
		}
		
	 });
	 setErrState(errArray);
  };

  const getErr =(key)=>{
	  if(!errState?.length){
		  return false;
	  } 
	 
	return errState.find((item) => { return item === key });
  }
 
  return (
    <div>
		<Header Title={Title}></Header>
		<form onSubmit={handleSubmit}>
			<div className="form-control">
				<label>Name:*</label>
				<input
					type="text"
					name="name"
					value={state.name}
					onChange={handleInputChange}
				/>
				{ getErr('name') && <p className="errorMsg">This field is required and cannot be empty</p> }
			</div>
			<div className="form-control">
				<label>Email:*</label>
				<input
					type="text"
					name="email"
					value={state.email}
					onChange={handleInputChange}
				/>
				{ getErr('email') && <p className="errorMsg">Please enter a valid email address</p> }
			</div>
			<div className="form-control">
				<label>Date of Birth:*</label>
				<DatePicker name="dob" selected={state.dob} onChange={(date) => setDate(date)} />
				{ getErr('dob') && <p className="errorMsg">This field is required and cannot be empty</p> }
			</div>
			<div className="form-control botton-15">
				<label>Pick your Favourite Colour:* <b>{state.color}</b></label>
				<SketchPicker
					color={ state.color }
					onChange={ handleChangeComplete }
				
				/>
				{ getErr('color') && <p className="errorMsg">This field is required and cannot be empty</p> }
			</div>
			<div className="form-control botton-15">
				<label>Choose your Salary:* <b> {state.salary}</b></label>
				<Slider
					min={20000}
					max={200000}
					value={state.salary}
					onChange={handleChange}
				/>
				{ getErr('salary') && <p className="errorMsg">This field is required and cannot be empty</p> }
			</div>
			<div className="form-control ">
				<label></label>
				<button type="submit" >Login</button>
			</div>
		</form>
    </div>
  );
}
