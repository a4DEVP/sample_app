export default function Head(props){
	return(
		<div className='head'>
			<h2>{props.Title}</h2>
		</div>
	)
}