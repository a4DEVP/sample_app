import React,{ useEffect, useState} from 'react';
import "./Gallery.css";
import "./Header";
import Header from './Header';
import LazyImage from 'react-lazy-blur-image';
import placeholder from "./images/place-holder.jpeg";
import like from "./images/like.png";
import { Card } from 'react-bootstrap';
import moment from 'moment'

function Gallery(){
	const Title = "Gallery";
	const appRef = React.useRef();
	const gallRef = React.useRef();
 
	const [isOpen, setIsOpen] = useState(false);
	const [popImg, setPopImg] = useState("");
	const [images, setImages] = useState();
	const placeholderImg = placeholder;

	useEffect(() => {
		fetch('images?limit=10')
		.then(res => res.json())
		.then(data => {
			console.log('Success:', data);
			setImages(data);
		})
		.catch(error => {
			console.error('Error:', error);
		});
	}, []);
	
	const togglePopup = (img='') => { 
		setPopImg(img);
		setIsOpen(!isOpen);
	}
	
	const getVal = (elem, style)=> { 
		return parseInt(window.getComputedStyle(elem).getPropertyValue(style)); 
	};

	useEffect(() => {
		if(appRef.current) {
			const gallery = document.querySelector('#gallery');
			document.querySelectorAll('img').forEach(function (item) {
				item.addEventListener('load', function () {
					const autorows = getVal(gallery, 'grid-auto-rows');
           			const gap = getVal(gallery, 'grid-row-gap');
					const gitem = item.parentElement.parentElement;
					gitem.style.gridRowEnd = "span " + Math.ceil((item.height + gap) / (autorows + gap));
				});
			});
		}
	  }, [appRef, gallRef, images])
	
	return (
		<>
			<Header Title={Title}></Header>
			 <div className="gallery" id="gallery" ref={gallRef}>
				 {images && images.map((img) => (
					 <>
						<div className="gallery-item" key={img.id}>
							<div className="content" title={img.alt_description} onClick={() => togglePopup(img)}>
								<LazyImage
									placeholder={placeholderImg}
									uri={`${img.url}.jpg`}
									render={(src, style) => <img src={src} alt={img.alt_description} key={img.id} ref={appRef} ></img>}
								/>
								<div className='user-img'>
									<img src={like} alt="" key={img.user.id}></img>{img.likes} 
								</div> 	
							</div>
						</div> 
					 </>
				 ))}
			</div>
			{isOpen && <div className="full" onClick={togglePopup}>
				<div className='details-card'>
					<Card>
						<LazyImage
							placeholder={placeholderImg}
							uri={`${popImg?.url}.jpg`}
							render={(src, style) => <Card.Img variant="top" src={src} />}
						/>
						<Card.Body>
							<Card.Title>
								<div className=' flex'>
								<p className="square" style={{backgroundColor : popImg?.color}}> </p> 
								<p>{popImg?.alt_description}</p>
								</div>
								<p className='info'>Posted : { moment(popImg?.created_at, "YYYYMMDD").fromNow()}</p>
							</Card.Title>
							{popImg?.description && <Card.Text>
							<div className='flex'>
								{popImg?.description}
							</div>
							</Card.Text>}
						</Card.Body>
						<Card.Body>
							<div className='flex'>
								<div>
									<Card.Text>
										<div className='profile-pic flex'>
											<LazyImage
												placeholder={placeholderImg}
												uri={`${popImg?.user?.profile_image}.webp`}
												render={(src, style) => <img src={src} alt=""></img>}
											/>	
										</div>
									</Card.Text>
								</div>
								<div>
									<Card.Title>{popImg?.user.name} </Card.Title>
									{popImg?.user?.location && <p className='info'>{popImg?.user?.location}</p>}
								</div>
							</div>
							<Card.Text>
								<div className='flex'>
									<p>Total Collections : </p> {popImg?.user?.total_collections}
								</div>
							</Card.Text>
							<Card.Text>
								<div className='flex'>
									<p>Total Likes : </p> {popImg?.user?.total_likes}
								</div>
							</Card.Text>
						</Card.Body>
					</Card>
				</div>
			</div>}
		 </>
	)
}

export default Gallery;