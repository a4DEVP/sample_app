import React from 'react';
import './App.css';
import Gallery from './components/Gallery'; 
import FormPage from "./components/FormPage";
import 'bootstrap/dist/css/bootstrap.min.css';
import {
	BrowserRouter as Router,
	Switch,
	Route,
	NavLink
  } from "react-router-dom";

const App = () => {

  return (
    <div className='app'>
		<Router>
			<div className='header'>
				<ul>
				<li>
					<NavLink to="/" className="hide"></NavLink>
				</li>
				<li>
					<NavLink activeClassName="active" to="/gallery">Gallery</NavLink>
				</li>
				<li>
					<NavLink activeClassName="active" to="/form">Form</NavLink>
				</li>
				</ul>
				<Switch>
					<Route exact path="/">
						<Gallery />
					</Route>
					<Route exact path="/gallery">
						<Gallery />
					</Route>
					<Route path="/form">
						<FormPage />
					</Route>
				</Switch>
			</div>
		</Router>
    </div>
  );
}

export default App;
